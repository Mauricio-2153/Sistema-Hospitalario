const { sql } = require('../config/database');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');

// Login
const login = async (req, res) => {
    try {
        const { usuario, contrasena } = req.body;

        // Validar que vengan los datos
        if (!usuario || !contrasena) {
            return res.status(400).json({ 
                success: false, 
                message: 'Usuario y contraseña son requeridos' 
            });
        }

        // Buscar usuario en la base de datos
        const result = await sql.query`
            SELECT UsuarioID, NombreCompleto, Usuario, Contrasena, Rol, ClinicaID, Estado
            FROM Usuarios 
            WHERE Usuario = ${usuario}
        `;

        if (result.recordset.length === 0) {
            return res.status(401).json({ 
                success: false, 
                message: 'Usuario o contraseña incorrectos' 
            });
        }

        const user = result.recordset[0];

        // Verificar si está activo
        if (!user.Estado) {
            return res.status(401).json({ 
                success: false, 
                message: 'Usuario desactivado' 
            });
        }

        // Por ahora comparamos contraseñas en texto plano
        // TODO: Encriptar contraseñas con bcrypt
        if (contrasena !== user.Contrasena) {
            return res.status(401).json({ 
                success: false, 
                message: 'Usuario o contraseña incorrectos' 
            });
        }

        // Generar JWT
        const token = jwt.sign(
            { 
                id: user.UsuarioID, 
                usuario: user.Usuario, 
                rol: user.Rol,
                clinicaId: user.ClinicaID 
            },
            process.env.JWT_SECRET,
            { expiresIn: process.env.JWT_EXPIRES_IN }
        );

        // Respuesta exitosa
        res.json({
            success: true,
            message: 'Login exitoso',
            token: token,
            usuario: {
                id: user.UsuarioID,
                nombre: user.NombreCompleto,
                usuario: user.Usuario,
                rol: user.Rol,
                clinicaId: user.ClinicaID
            }
        });

    } catch (error) {
        console.error('Error en login:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error en el servidor' 
        });
    }
};

module.exports = { login };